import React from 'react'
import 'styles/about.css'

function About() {
  return (

    <div className='about'>
      <div className='section_title'>
        <h2>About -</h2>
        <ul>
          <li>Me</li>
          <li>Skill</li>
        </ul>
      </div>
      <div className='about_contents'>
        <div className='about_me'>
          <div className='about_me_top'>
            <div className='about_me_left about_me_text'>
              <dl>
                <dt>About me</dt>
                <dd>이상현</dd>
                <dd>1993.11.17</dd>
                <dd>서울시 동작구 거주 중</dd>
              </dl>
            </div>
            <div className='about_me_right about_me_text'>
              <dl>
                <dt>Contact</dt>
                <dd>010.6685.0145</dd>
                <dd>aromad1117@naver.com</dd>
              </dl>
            </div>
          </div>
          <div className='about_me_bottom about_me_text'>
            <dl>
              <dt>History</dt>
              <dd>2019.07 ~ 2019.10 블록체인 미르 개발팀 입사 - 퍼블리셔 업무</dd>
              <dd>뉴비코 홈페이지 제작</dd>
              <dd>2022.12 ~ 2023.05 이젠 평생 교육원 UI/UX 웹&앱 디자인 & 프론트엔드 강의 수료</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About