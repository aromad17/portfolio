import React from 'react'

function Work() {
  return (
    <div>Work</div>
  )
}

export default Work